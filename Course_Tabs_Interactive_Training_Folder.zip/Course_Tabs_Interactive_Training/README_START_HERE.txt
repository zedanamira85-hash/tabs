COURSE TABS — INTERACTIVE TRAINING

1. Open lesson/index.html in Chrome to study the interactive explanation, examples and quiz.
2. Open the entire folder in VS Code. The lesson files are separated into index.html, style.css, and script.js.
3. For independent student practice, open student-practice/index.html and complete student-practice/script.js.
4. Read student-practice/TASK.txt for the original Chief Expert task requirements.
5. Everything works offline. No installation required.

Note: The lesson teaches the provided index-based click solution. Browser title changes and arrow-key support are extension requirements in the original task.
